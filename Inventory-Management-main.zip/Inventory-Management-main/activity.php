<?php include("connection.php");?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <title>Contact Form</title>
  </head>
  <body
    class="bg-gradient-to-r from-blue-100 to-purple-200 min-h-screen flex items-center justify-center"
  >
    <div class="bg-white p-8 rounded-2xl shadow-lg w-full max-w-md">
      <h2 class="text-2xl font-bold text-center text-gray-800 mb-6">
        Login 
      </h2>

      <form
        id="contactForm"
        action=""
        method="POST"
        required class="space-y-4"
        onsubmit="loginuser(event)"
      >
        <div>
          <label class="block mb-1 font-medium text-gray-700" for="name"
            >Name</label
          >
          <input
            type="text"
            id="name"
            name="name"
            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
          />
           <span id="blank_name" class="text-xl text-red-800"></span>
        </div>

        <div>
          <label class="block mb-1 font-medium text-gray-700" for="email"
            >Email</label
          >
          <input
            type="email"
            id="email"
            name="email"
            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
          />
          <span id="blank_email" class="text-xl text-red-800"></span>
        </div>

        <div>
          <label class="block mb-1 font-medium text-gray-700" for="message"
            >Password</label
          >
          <input
            id="message"
            type="text"
            name="message"
            rows="4"
            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
          ></input>
        </div>

        <div class="flex items-center">
          <input type="checkbox" id="terms" name="terms" class="mr-2" />
          <label for="terms" class="text-gray-700 text-sm"
            >I agree to all terms and conditions</label
          >
        </div>

        <button
          type="submit"
          name="register"
          id="btn"
          class="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg transition duration-200"
        >
          Register
        </button>
      </form>

      <div
        id="successMessage"
        class="hidden text-center text-green-700 font-semibold mt-6"
      >
        ✅ Form submitted successfully!
      </div>
    </div>

    <script>
      const email = document.getElementById("email");
      console.log(email);
      const name = document.getElementById("name");
      console.log(name);
      const blankname = document.getElementById("blank_name");
      const blankEmail = document.getElementById("blank_email");
      const form = document.getElementById("contactForm");
      const successMessage = document.getElementById("successMessage");

      function loginuser(event) {
        event.preventDefault();

        const validEmail = "sourodipdey19@gmail.com";
        const validname = "Sourodip Dey";


        if (!name.value && !email.value) {
          blankname.textContent = "Please enter name";
          blankEmail.textContent = "Please enter email";
          return;
        } 
        
        else if(!name.value && email.value){
             blankname.textContent = "Please enter name";
              return;
        }
        else if(!email.value && name.value){
              blankEmail.textContent = "Please enter email";
              return;
        }
        else {
          blankname.textContent = "";
        }


        

       

        if (email.value === validEmail && name.value === validname) {
          // alert("yay !! successful");
          // form.classList.toggle("hidden"); // hide the form
          // successMessage.classList.toggle("hidden"); // show success message
          window.location.href = 'project2.html';
        } else {
          alert("Wrong email or name");
        }
      }
    </script>
  </body>
</html>


<?php
if (isset($_POST['register'])) {
    $name  = $_POST["name"];
    $email = $_POST["email"];
    $msg   = $_POST["message"];
    
    $query = "INSERT INTO user_data VALUES ('$name', '$email', '$msg')";
  
    $data = mysqli_query($conn, $query);

    if ($data) {
        echo "Success";
    } else {
        echo "Failed";
    }
}
?>
